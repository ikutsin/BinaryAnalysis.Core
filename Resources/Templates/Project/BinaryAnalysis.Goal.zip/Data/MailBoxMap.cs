﻿using System;
using System.Runtime.Serialization;
using System.Xml.Serialization;
using BinaryAnalysis.Data.Box;
using Newtonsoft.Json;

namespace BinaryAnalysis.$safeprojectname$.Data
{
    [Serializable,XmlType("Mail"),DataContract,JsonObject]
    public class MailBoxMap : EntityBoxMap
    {
        [DataMember, XmlElement, JsonProperty]
        public string Name { get; set; }
    }
}
