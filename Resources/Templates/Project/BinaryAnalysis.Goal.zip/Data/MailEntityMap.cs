﻿using BinaryAnalysis.Data.Core.Impl;

namespace BinaryAnalysis.$safeprojectname$.Data
{
    class MailEntityMap : EntityClassMap<MailEntity>
    {
        public MailEntityMap()
        {
            Map(x => x.Name).Not.Nullable();
        }
    }
}
