﻿using System.Linq;
using BinaryAnalysis.Data.Classification;
using BinaryAnalysis.Data.Core;
using log4net;

namespace BinaryAnalysis.$safeprojectname$.Data
{
    public class MailRepository : ClassifiableRepository<MailEntity>
    {
        public MailRepository(IDbContext context, ILog log, RelationRepository relRepo)
            : base(context, log, relRepo)
        {
        }

        public MailEntity LoadByName(string host)
        {
            using (var wu = SessionManager.WorkUnitFor(this, DbWorkUnitType.Read))
            {
                var result = AsQueryable(wu.Session)
                    .Where(x => x.Name == host)
                    .FirstOrDefault();
                return result;
            }
        }
    }
}
