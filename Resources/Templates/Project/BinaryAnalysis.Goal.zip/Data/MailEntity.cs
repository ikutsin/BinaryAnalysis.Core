﻿using BinaryAnalysis.Data.Box;
using BinaryAnalysis.Data.Classification;
using BinaryAnalysis.Data.Core.Impl;
using NHibernate.Validator.Constraints;

namespace BinaryAnalysis.$safeprojectname$.Data
{
    [BoxTo(typeof(MailBoxMap))]
    public class MailEntity : Entity, IClassifiable
    {
        public MailEntity()
        {
        }
        [NotNullNotEmpty, Length(255)]
        public virtual string Name { get; set; }

        public virtual string ObjectName
        {
            get { return "Mail"; }
        }
    }
}
