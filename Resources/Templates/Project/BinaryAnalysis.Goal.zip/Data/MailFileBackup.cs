﻿using System.Collections.Generic;
using BinaryAnalysis.Box.Transforations;
using BinaryAnalysis.Data.Box;

namespace BinaryAnalysis.$safeprojectname$.Data
{
    public class MailFileBackup : NHibernateFileBackupBase<MailBoxMap, MailEntity>
    {
        public MailFileBackup(FileBoxTransformation<MailBoxMap> fileTransform, NHibernateBoxTransformation<MailBoxMap, MailEntity> dbTransform)
            : base(fileTransform, dbTransform)
        {
            dbTransform.FindExistingEntity = (repo, e) => repo.FindOne(new Dictionary<string, object> { { "Name", e.Name } });
        }
    }
}
