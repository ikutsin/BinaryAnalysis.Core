﻿using System;
using System.Collections.Generic;
using Autofac;
using BinaryAnalysis.$safeprojectname$.Data;
using BinaryAnalysis.Data.Core;

namespace BinaryAnalysis.$safeprojectname$
{
    class DomainModule : Module
    {
        protected override void Load(ContainerBuilder builder)
        {


            //database
            builder.RegisterType<MailRepository>().InstancePerDependency();
            builder.RegisterType<NHMailConfig>().As<INHMappingsProvider>().SingleInstance();
            builder.RegisterType<MailFileBackup>().InstancePerDependency();
        }
    }
    public class NHMailConfig : INHMappingsProvider
    {
        public IList<Type> FluentMappings
        {
            get
            {
                return new List<Type>()
                {
                    typeof(MailEntityMap),
                };
            }
        }
    }
}
