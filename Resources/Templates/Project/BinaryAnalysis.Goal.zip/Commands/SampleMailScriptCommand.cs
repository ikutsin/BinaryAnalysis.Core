﻿using System;
using System.Net;
using BinaryAnalysis.Scheduler.Task.Script;

namespace BinaryAnalysis.$safeprojectname$.Commands
{
    public class SampleMailScriptCommand : IScriptUtilityCommand
    {
        public Type InputType
        {
            get { return typeof (String); }
        }

        public Type ReturnType
        {
            get { return typeof(String); }
        }

        public object Execute(ScriptUtility x, object input)
        {
            throw new NotImplementedException("TODO");
        }
    }
}
