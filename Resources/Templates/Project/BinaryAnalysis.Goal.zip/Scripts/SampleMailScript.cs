﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using BinaryAnalysis.Browsing.Extensions;
using BinaryAnalysis.Scheduler;
using BinaryAnalysis.Scheduler.Task.Script;

namespace BinaryAnalysis.$safeprojectname$.Scripts
{
    public class SampleMailScriptDependencies : SchedulerTaskScriptDependencies
    {
        public override IEnumerable<string> RequiredSettings
        {
            get { return new[] { SampleMailScript.SETTING_EXAMPLE }; }
        }
    }
    public class SampleMailScript : AbstractTaskScript
    {
        public const string SETTING_EXAMPLE = "SampleMailScript_example";
        public const string SETTING_RESULT = "SampleMailScript_result";


        public override void Execute()
        {
            //var addr = "http://sameip.org/ip/{0}";
            //string example = x.Settings.Get<string>(SETTING_EXAMPLE);
            //var response = x.BrowserWL.NavigateGet(new Uri(string.Format(addr, domain)));
            //var doc = response.AsHtmlDocument();
            //x.Settings.Set(SETTING_RESULT, result);
        }

        public override Type DependencyClassType
        {
            get { return typeof(SampleMailScriptDependencies); }
        }
    }
}
